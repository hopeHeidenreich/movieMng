﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace MovieRentSystem2
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection("Server = ZCM-704203682\\SQLEXPRESS; database=Database5; Integrated Security = true");
        Movies Movies = new Movies();
        Users User = new Users();
        Rents Rents = new Rents();

        public Form1()
        {
            InitializeComponent();
        }

        private void moviesItem_Click(object sender, EventArgs e)
        {
            Movies.Show();
        }

        private void usersItem_Click(object sender, EventArgs e)
        {
            User.Show();
        }

        private void rentsItem_Click(object sender, EventArgs e)
        {
            Rents.Show();
        }

        private void LoadMovie_Info()
        {
            conn.Open();
            SqlCommand selectAllCmd = conn.CreateCommand();
            selectAllCmd.CommandText = "SELECT MovieID as [Movie ID], MovieTitle as [Title], MovieDirector as [Director], MovieActors as [Actors], MovieGenre as [Genre], Premiere, Availability FROM Movies";
            selectAllCmd.ExecuteNonQuery();
            DataTable mTable = new DataTable();
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(selectAllCmd);
            sqlAdapter.Fill(mTable);
            dataGridView1.DataSource = mTable;

            dataGridView1.Visible = true;

            conn.Close();
        }

        private void LoadUser_Info()
        {
            conn.Open();
            SqlCommand selectAllCmd = conn.CreateCommand();
            selectAllCmd.CommandText = "SELECT UserID as [User ID], UserName as [Name], UserAddress as [Address], UserPhone as [Phone], UserEmail as [Email], UserZip as [ZIP] FROM Users";
            selectAllCmd.ExecuteNonQuery();
            DataTable uTable = new DataTable();
            SqlDataAdapter sql2Adapter = new SqlDataAdapter(selectAllCmd);
            sql2Adapter.Fill(uTable);
            dataGridView1.DataSource = uTable;

            dataGridView1.Visible=true;
            conn.Close();
        }

        private void LoadAvailMovies_Info()
        {
            conn.Open();
            SqlCommand selectAllCmd = conn.CreateCommand();
            selectAllCmd.CommandText = "SELECT MovieID as [Movie ID], MovieTitle as [Title], MovieDirector as [Director], MovieActors as [Actors], MovieGenre as [Genre], Premiere, Availability FROM Movies WHERE Premiere = 'true'";
            selectAllCmd.ExecuteNonQuery();
            DataTable maTable = new DataTable();
            SqlDataAdapter sql3Adapter = new SqlDataAdapter(selectAllCmd);
            sql3Adapter.Fill(maTable);
            dataGridView1.DataSource = maTable;

            dataGridView1.Visible = true;

            conn.Close();
        }

        private void LoadRentedMovies_Info()
        {
            conn.Open();
            SqlCommand selectAllCmd = conn.CreateCommand();
            selectAllCmd.CommandText = "SELECT Movies.MovieTitle as [Title], Rentals.MovieID as [Movie ID], Rentals.UserID as [User ID] FROM Rentals INNER JOIN Movies ON Rentals.MovieID = Movies.MovieID";
            selectAllCmd.ExecuteNonQuery();
            DataTable mrTable = new DataTable();
            SqlDataAdapter sql4Adapter = new SqlDataAdapter(selectAllCmd);
            sql4Adapter.Fill(mrTable);
            dataGridView1.DataSource = mrTable;

            dataGridView1.Visible = true;

            conn.Close();
        }

        private void searchTitle_Load()
        {
            conn.Open();
            SqlCommand searchCmd = conn.CreateCommand();
            searchCmd.CommandText = "SELECT MovieTitle as [Title], MovieID as [Movie ID], MovieDirector as [Director], MovieActors as [Actors], MovieGenre as [Genre], Premiere, Availability FROM Movies ORDER BY MovieTitle ASC";
            searchCmd.ExecuteNonQuery();
            DataTable stTable = new DataTable();
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(searchCmd);
            sqlAdapter.Fill(stTable);
            dataGridView1.DataSource = stTable;

            dataGridView1.Visible = true;

            conn.Close();
        }

        private void searchDir_Load()
        {
            conn.Open();
            SqlCommand searchCmd = conn.CreateCommand();
            searchCmd.CommandText = "SELECT MovieDirector as [Director], MovieID as [Movie ID], MovieTitle as [Title], MovieActors as [Actors], MovieGenre as [Genre], Premiere, Availability FROM Movies ORDER BY MovieDirector ASC";
            searchCmd.ExecuteNonQuery();
            DataTable sdTable = new DataTable();
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(searchCmd);
            sqlAdapter.Fill(sdTable);
            dataGridView1.DataSource = sdTable;

            dataGridView1.Visible = true;

            conn.Close();
        }

        private void searchGenre_Load()
        {
            conn.Open();
            SqlCommand searchCmd = conn.CreateCommand();
            searchCmd.CommandText = "SELECT MovieGenre as [Genre], MovieID as [Movie ID], MovieTitle as [Title], MovieDirector as [Director], MovieActors as [Actors], Premiere, Availability FROM Movies ORDER BY MovieGenre ASC";
            searchCmd.ExecuteNonQuery();
            DataTable sgTable = new DataTable();
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(searchCmd);
            sqlAdapter.Fill(sgTable);
            dataGridView1.DataSource = sgTable;

            dataGridView1.Visible = true;

            conn.Close();
        }

        private void moviesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.moviesBindingSource.EndEdit();

        }

        private void listOfUsersItem_Click(object sender, EventArgs e)
        {
            LoadUser_Info();
        }

        private void listOfMoviesItem_Click(object sender, EventArgs e)
        {
            LoadMovie_Info();
        }

        private void allAvailableMoviesItem_Click(object sender, EventArgs e)
        {
            LoadAvailMovies_Info();
        }

        private void allRentedMoviesItem_Click(object sender, EventArgs e)
        {
            LoadRentedMovies_Info();
        }

        private void titleItem_Click(object sender, EventArgs e)
        {
            searchTitle_Load();
        }

        private void directorItem_Click(object sender, EventArgs e)
        {
            searchDir_Load();
        }

        private void genreItem_Click(object sender, EventArgs e)
        {
            searchGenre_Load();

        }
    }
}
