﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace MovieRentSystem2
{
    public partial class Movies : Form
    {
        SqlConnection conn = new SqlConnection("Server = ZCM-704203682\\SQLEXPRESS; database=Database5; Integrated Security = true");

        public Movies()
        {
            InitializeComponent();
        }

        

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string title = txtTitle.Text;
            string dir = txtDirector.Text;
            string acts = txtActors.Text;
            string genre = txtGenre.Text;
            string premiere;
            string avail;
            if (chkPremiere.Checked)
            {
                premiere = "true";
            }
            else
            {
                premiere = "false";
            }
            if (chkAvailable.Checked)
            {
                avail = "true";
            }
            else
            {
                avail = "false";
            }
            if (title != "" && dir != "" && acts !="" && genre != "")
            {
                conn.Open();
                SqlCommand insertCmd = conn.CreateCommand();
                insertCmd.CommandText = String.Format("INSERT INTO Movies (MovieTitle, MovieDirector, MovieActors, MovieGenre, Premiere, Availability) VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')", title, dir, acts, genre, premiere, avail);
                insertCmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Record Successfully Inserted!");

                txtTitle.Clear();
                txtDirector.Clear();
                txtActors.Clear();
                txtGenre.Clear();
                chkPremiere.Checked = false;
                chkAvailable.Checked = false;
            } else
            {
                MessageBox.Show("Please fill out ALL fields!");
            }
            
            

            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
