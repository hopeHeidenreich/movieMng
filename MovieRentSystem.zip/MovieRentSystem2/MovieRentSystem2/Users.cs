﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieRentSystem2
{
    public partial class Users : Form
    {
        SqlConnection conn = new SqlConnection("Server = ZCM-704203682\\SQLEXPRESS; database=Database5; Integrated Security = true");

        public Users()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void btnInsert_Click(object sender, EventArgs e)
        {
            
            string userName = txtName.Text;
            string address = txtAdd.Text;
            string zip = txtZIP.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;

            if (userName != "" && address != "" && zip != "" && email != "" && phone != "")
            {
                conn.Open();
                SqlCommand insertCmd = conn.CreateCommand();
                insertCmd.CommandText = String.Format("INSERT INTO Users (UserName, UserAddress, UserPhone, UserEmail, UserZip) VALUES('{0}', '{1}', '{2}', '{3}', '{4}')", userName, address, phone, email, zip);
                insertCmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Record Successfully Inserted!");

                txtName.Clear();
                txtAdd.Clear();
                txtEmail.Clear();
                txtPhone.Clear();
                txtZIP.Clear();
            } else
            {
                MessageBox.Show("Please fill out ALL fields!");
            }

            
        }

    }
}
