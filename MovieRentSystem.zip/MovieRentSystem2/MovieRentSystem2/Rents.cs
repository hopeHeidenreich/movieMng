﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieRentSystem2
{
    public partial class Rents : Form
    {
        SqlConnection conn = new SqlConnection("Server = ZCM-704203682\\SQLEXPRESS; database=Database5; Integrated Security = true");

        public Rents()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void btnInsert_Click(object sender, EventArgs e)
        {
            string mID = txtMovieID.Text;
            string uID = txtUserID.Text;

            if (mID != "" && uID != "")
            {
                conn.Open();
                SqlCommand insertCmd = conn.CreateCommand();
                insertCmd.CommandText = String.Format("INSERT INTO Rentals (MovieID, UserID) VALUES('{0}', '{1}')", mID, uID);
                insertCmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Record Successfully Inserted!");

                txtMovieID.Clear();
                txtUserID.Clear();
            } else
            {
                MessageBox.Show("Please fill out ALL fields!");
            }
            
        }

    }
}
